package com.example.getfitgo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login_user extends AppCompatActivity {


    EditText edtbox_edt_mobile_number,edtbox_edt_password;
    Button main_btn_submit;
    TextView main_txt_register,main_txt_forgot_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_user);

        edtbox_edt_mobile_number = (EditText)findViewById(R.id.edt_mobile_number);
        edtbox_edt_password = (EditText)findViewById(R.id.edt_password);

        main_btn_submit = (Button) findViewById(R.id.btn_submit);

        main_txt_register = (TextView) findViewById(R.id.txt_register);
        main_txt_forgot_password = (TextView) findViewById(R.id.txt_forgot_password);

        main_txt_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login_user.this, Register.class);
                startActivity(intent);
            }
        });

        main_txt_forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login_user.this, Forgot_password.class);
                startActivity(intent);
            }
        });

        main_btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login_user.this, Dashboard.class);
                startActivity(intent);
            }
        });

    }
}