package com.example.getfitgo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Dashboard extends AppCompatActivity {

    Button main_qa_btn,main_about_us_btn,main_contact_us_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        main_qa_btn = (Button) findViewById(R.id.q_a_btn);
        main_about_us_btn = (Button) findViewById(R.id.about_us_btn);
        main_contact_us_btn= (Button) findViewById(R.id.contact_us_btn);

        main_qa_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, question_answers.class);
                startActivity(intent);
            }
        });

        main_about_us_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, about_us.class);
                startActivity(intent);
            }
        });

        main_contact_us_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, contact_us.class);
                startActivity(intent);
            }
        });


    }
}