package com.example.getfitgo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class question_answers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_answers);
    }
}