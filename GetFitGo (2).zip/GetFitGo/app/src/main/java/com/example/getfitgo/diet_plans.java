package com.example.getfitgo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class diet_plans extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plans);


    }
}